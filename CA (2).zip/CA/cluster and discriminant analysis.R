data<-read.csv(file.choose(),header=T)
data=scale(data)
data=data.frame(data)
names(data)
str(data)
head(data)
d=dist(data)
#d

#data[1:2,]
#d=dist(data[1:2,1:2])
#d
#sqrt((6-2)^2+(4-3)^2)
hc<-hclust(d)
plot(hc,labels = FALSE)  #it is giving dendogram
#plot(hc)

library(NbClust)
nc<- NbClust(data,min.nc=2, max.nc=6,method="kmeans")
nc
barplot(table(nc$Best.n[1,]),
        xlab="Numer of Clusters",
        ylab="Number of Criteria",
        main="Number of Clusters Chosen")


(cl<-kmeans(data,3))

#plot(data,col=cl$cluster)
#points(cl$centers, col = 1:2, pch = 8, cex = 2)
#View(cl$cluster)
split(data,cl$cluster)
y=cl$cluster


#### Discriminant Analysis
X=data

library(mvnormtest)
mshapiro.test(t(X)) # Minimum three variables require
# Box M test for homogeniety of variance covariance matrix 
#load packages MVTests, matrixcalc
library(MVTests)
BoxM(X,y)
data=data.frame(X,y)
data
N=length(X[,1]); N
n=round(0.7*N) ; n
data_model=sample(N,n)
data_model
data.model<-data[data_model,]
data.model
data.validation<-data[-data_model,]
data.validation
library(MASS)
lda.wine<-lda(y~.,data=data,prior=c(1,1,1)/3,sample=data_model)
lda.wine
predictive.model<-predict(lda.wine,data.validation)
predictive.model
predictive_class<-predictive.model$class
predictive_class
model_class<-data.validation[,14]
model_class
classification<-table(model_class,predictive_class)
classification
classification.prob=sum(diag(classification))/(N-n)
classification.prob
missclass.prob=1-classification.prob
missclass.prob

sapply(data,mean)


#calucalte the class when x1=144, x2=236

x.data=data.frame(Alcohol= 13.000618,Malic=2.3363483,  Ash=2.3665169, Alcalinity=19.4949438,
                  Magnesium=99.7415730, Phenols=2.2951124, Flavanoids= 2.0292697,
                  Nonflavanoids=0.3618539,  Proanthocyanins= 1.5908989,Color=5.0580899,  
                  Hue=0.9574494,Dilution=2.6116854,Proline=746.8932584)
x.data
predict.model<-predict(lda.wine,x.data)
predict.model



###logisti regression....




##### After standarizing data of wine

###########################

data<-read.csv(file.choose(),header=T)
data
names(data)
str(data)
head(data)
d=dist(data)
#d

#data[1:2,]
#d=dist(data[1:2,1:2])
#d
#sqrt((6-2)^2+(4-3)^2)
hc<-hclust(d)
plot(hc,labels = FALSE)  #it is giving dendogram
#plot(hc)

library(NbClust)
nc<- NbClust(data,min.nc=2, max.nc=6,method="kmeans")
nc
barplot(table(nc$Best.n[1,]),
        xlab="Numer of Clusters",
        ylab="Number of Criteria",
        main="Number of Clusters Chosen")


(cl<-kmeans(data,2))

#plot(data,col=cl$cluster)
#points(cl$centers, col = 1:2, pch = 8, cex = 2)
#View(cl$cluster)
split(data,cl$cluster)
y=cl$cluster


#### Discriminant Analysis
X=data

library(mvnormtest)
mshapiro.test(t(X)) # Minimum three variables require
# Box M test for homogeniety of variance covariance matrix 
#load packages MVTests, matrixcalc
library(MVTests)
BoxM(X,y)
data=data.frame(X,y)
data
N=length(X[,1]); N
n=round(0.7*N) ; n
data_model=sample(N,n)
data_model
data.model<-data[data_model,]
data.model
data.validation<-data[-data_model,]
data.validation
library(MASS)
lda.wine<-lda(y~.,data=data,prior=c(1,1)/2,sample=data_model)
lda.wine
predictive.model<-predict(lda.wine,data.validation)
predictive.model
predictive_class<-predictive.model$class
predictive_class
model_class<-data.validation[,14]
model_class
classification<-table(model_class,predictive_class)
classification
classification.prob=sum(diag(classification))/(N-n)
classification.prob
missclass.prob=1-classification.prob
missclass.prob

sapply(data,mean)


#calucalte the class when x1=144, x2=236

x.data=data.frame(Alcohol= 13.000618,Malic=2.3363483,  Ash=2.3665169, Alcalinity=19.4949438,
                  Magnesium=99.7415730, Phenols=2.2951124, Flavanoids= 2.0292697,
                  Nonflavanoids=0.3618539,  Proanthocyanins= 1.5908989,Color=5.0580899,  
                  Hue=0.9574494,Dilution=2.6116854,Proline=746.8932584)
x.data
predict.model<-predict(lda.wine,x.data)
predict.model


################################



################Toothpaste

tooth=read.table("D:toothpaste_1.txt",header=T)
tooth
tooth=tooth[-1]
tooth
#wine.stand<- scale(wine[-1])  # To standarize the variables
#str(wine)
summary(tooth)
cor(tooth)
#Hierarchical clustering:
d <- dist(tooth) 
H.fit<- hclust(d)
plot(H.fit) # display dendogram
library(NbClust)
nc<- NbClust(tooth,min.nc=2, max.nc=6,method="kmeans")
barplot(table(nc$Best.n[1,]),
        xlab="Numer of Clusters",
        ylab="Number of Criteria",
        main="Number of Clusters Chosen")

groups<- cutree(H.fit, k=3) # cut tree into 3 clusters
# drawdendogram with red borders around the 3 clusters
rect.hclust(H.fit, k=3, border="red")

####Kmeans

#Fit the model
tooth_clustered<- kmeans(tooth, 3) # k = 3
options(digits=2)
C1=sapply(tooth[tooth_clustered$cluster==1,],mean)
C2=sapply(tooth[tooth_clustered$cluster==2,],mean)
C3=sapply(tooth[tooth_clustered$cluster==3,],mean)
rbind(C1,C2,C3)

plot(tooth,col=tooth_clustered$cluster)
points(tooth_clustered$centers, col = 1:5, pch = 8, cex = 2)
tooth_clustered
a=split(tooth,tooth_clustered$cluster)
cl1.data=a$'1'
cl2.data=a$'2'
cl3.data=a$'3'
cl1.data; cl2.data; cl3.data
View(cl1.data)
View(cl2.data)
View(cl3.data)