x <- rbind(matrix(rnorm(100, sd = 0.3), ncol = 2),
           matrix(rnorm(100, mean = 1, sd = 0.3), ncol = 2))
          
x <- rbind(matrix(rnorm(90, sd = 0.3), ncol = 2),
           matrix(rnorm(90, mean = 1, sd = 0.3), ncol = 2),
           matrix(rnorm(90, mean = 2, sd = 0.3), ncol = 2))

help("hclust")
hc=hclust(dist(x))
hc
plot(hc,labels = FALSE)

colnames(x) <- c("x", "y")
x
(cl <- kmeans(x, 3))
cl$cluster
plot(x, col = cl$cluster)
points(cl$centers, col = 1:3, pch = 8, cex = 2)
a=split(x,cl$cluster)
a

# Cluster Analysis for Attitude Data

data<-read.table(file.choose(),header=T)
data
data=data[,-1]
data
d=dist(data)
d

#data[1:2,]
#d=dist(data[1:2,1:2])
#d
#sqrt((6-2)^2+(4-3)^2)
hc<-hclust(d)
plot(hc,labels = FALSE)  #it is giving dendogram
plot(hc)

library(NbClust)
nc<- NbClust(data,min.nc=2, max.nc=6,method="kmeans")
nc
barplot(table(nc$Best.n[1,]),
        xlab="Numer of Clusters",
        ylab="Number of Criteria",
        main="Number of Clusters Chosen")


(cl<-kmeans(data,3))

plot(data,col=cl$cluster)
points(cl$centers, col = 1:2, pch = 8, cex = 2)
View(cl$cluster)
split(data,cl$cluster)
y=cl$cluster

################Toothpaste

tooth=read.table("D:toothpaste_1.txt",header=T)
tooth
tooth=tooth[-1]
tooth
#wine.stand<- scale(wine[-1])  # To standarize the variables
#str(wine)
summary(tooth)
cor(tooth)
#Hierarchical clustering:
d <- dist(tooth) 
H.fit<- hclust(d)
plot(H.fit) # display dendogram
library(NbClust)
nc<- NbClust(tooth,min.nc=2, max.nc=6,method="kmeans")
barplot(table(nc$Best.n[1,]),
        xlab="Numer of Clusters",
        ylab="Number of Criteria",
        main="Number of Clusters Chosen")

groups<- cutree(H.fit, k=3) # cut tree into 3 clusters
# drawdendogram with red borders around the 3 clusters
rect.hclust(H.fit, k=3, border="red")

####Kmeans

#Fit the model
tooth_clustered<- kmeans(tooth, 3) # k = 3
options(digits=2)
C1=sapply(tooth[tooth_clustered$cluster==1,],mean)
C2=sapply(tooth[tooth_clustered$cluster==2,],mean)
C3=sapply(tooth[tooth_clustered$cluster==3,],mean)
rbind(C1,C2,C3)

plot(tooth,col=tooth_clustered$cluster)
points(tooth_clustered$centers, col = 1:5, pch = 8, cex = 2)
tooth_clustered
a=split(tooth,tooth_clustered$cluster)
cl1.data=a$'1'
cl2.data=a$'2'
cl3.data=a$'3'
cl1.data; cl2.data; cl3.data
View(cl1.data)
View(cl2.data)
View(cl3.data)

##########
data=data.entry(x,y,z) # if data is numeric select variable is of type numeric
# call data by individual variables like x, y and z
datasets::chickwts
aggregate(weight~feed,data=chickwts,mean)

help("kmeans")
