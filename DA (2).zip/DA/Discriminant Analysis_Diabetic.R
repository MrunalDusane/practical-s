diab<-read.csv(file.choose(),header=TRUE)
diab
X=diab[,2:3]; X

library(mvnormtest)
mshapiro.test(t(X)) # Minimum three variables require
# Box M test for homogeniety of variance covariance matrix 
#load packages MVTests, matrixcalc
library(MVTests)
BoxM(diab[,2:3],diab[,1])
N=length(X[,1]); N
n=round(0.7*N) ; n
data_model=sample(N,n)
data_model
data.model<-diab[data_model,]
data.model
data.validation<-diab[-data_model,]
data.validation
library(MASS)
lda.diab<-lda(y~x1+x2,data=diab,prior=c(1,1)/2,sample=data_model)
lda.diab
predictive.model<-predict(lda.diab,data.validation)
predictive.model
predictive_class<-predictive.model$class
predictive_class
model_class<-data.validation[,1]
model_class
classification<-table(model_class,predictive_class)
classification
classification.prob=sum(diag(classification))/(N-n)
classification.prob
missclass.prob=1-classification.prob
missclass.prob

#calucalte the class when x1=144, x2=236

x.data=data.frame(x1=144,x2=236)
x.data
predict.model<-predict(lda.diab,x.data)
predict.model




###########Just for knowledge#######3
tr <- sample(1:50, 25)
tr
train <- rbind(iris3[tr,,1], iris3[tr,,2], iris3[tr,,3])
train
mshapiro.test(t(train))
BoxM(train,cl)
test <- rbind(iris3[-tr,,1], iris3[-tr,,2], iris3[-tr,,3])
cl <- factor(c(rep("s",25), rep("c",25), rep("v",25)))
z <- qda(train, cl)
predict(z,test)$class
table(cl,predict(z,test)$class)
help("qda")


Iris <- data.frame(rbind(iris3[,,1], iris3[,,2], iris3[,,3]),
                   Sp = rep(c("s","c","v"), rep(50,3)))
train <- sample(1:150, 75)
table(Iris$Sp[train])
z <- lda(Sp ~ ., Iris, prior = c(1,1,1)/3, subset = train)
zpre=predict(z, Iris[-train, ])$class
table(z,zpre)

