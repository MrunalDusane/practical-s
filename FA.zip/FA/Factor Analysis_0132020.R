tooth.paste<-read.table(file.choose(),header=TRUE) # Import the data from notpad
tooth.paste 
tooth.paste<-tooth.paste[,-1] #removal of first column from data
tooth.paste

# load packages psych, REdaS
library(psych)
library(REdaS)
R<-cor(tooth.paste) # correlation matrix of data
round(R,2)

bart_spher(tooth.paste)
KMOS(tooth.paste)

principle_component<-prcomp(tooth.paste) #Principle Component Analysis
principle_component
summary(principle_component)

#### Principle component loading plots
require(graphics)
biplot(prcomp(tooth.paste)) # Principle component loading plots
#summary(tooth.paste)
screeplot(principle_component,type="line")  # Generation of Scree Plot

factor.analysis0<-factanal(x=tooth.paste,factors=2,scores="Bartlett",rotation="none")
factor.analysis0


factor.analysis<-factanal(x=tooth.paste,factors=2,scores="Bartlett",rotation="varimax")
factor.analysis

factor.analysis_1<-factanal(x=tooth.paste,factors=3,scores="Bartlett",rotation="varimax")
factor.analysis_1 # having three factors

apply(tooth.paste,2,FUN=mean)

